<?php 
class Compress {



    public function compress_image($tempPath, $originalPath, $imageQuality){
			
        // Get image info 
        $imgInfo = getimagesize($tempPath); 
        $mime = $imgInfo['mime']; 
        
        // Create a new image from file 
        switch($mime){ 
            case 'image/jpeg': 
                $image = imagecreatefromjpeg($tempPath); 
                break; 
            case 'image/png': 
                $image = imagecreatefrompng($tempPath); 
                break; 
            case 'image/gif': 
                $image = imagecreatefromgif($tempPath); 
                break; 
            default: 
                $image = imagecreatefromjpeg($tempPath); 
        } 
        
        // Save image 
        imagejpeg($image, $originalPath, $imageQuality);    
        // Return compressed image 
        return $originalPath; 
    }

}