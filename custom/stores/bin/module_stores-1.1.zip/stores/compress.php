<?php


class Compress {

      

    public function compress_image($tempPath, $originalPath, $imageQuality){
			
        // Get image info 
        $imgInfo = getimagesize($tempPath); 
        $mime = $imgInfo['mime']; 
        
        // Create a new image from file 
        switch($mime){ 
            case 'image/jpeg': 
                $image = imagecreatefromjpeg($tempPath); 
                break; 
            case 'image/png': 
                $image = imagecreatefrompng($tempPath); 
                break; 
            case 'image/gif': 
                $image = imagecreatefromgif($tempPath); 
                break; 
            default: 
                $image = imagecreatefromjpeg($tempPath); 
        } 
        
        // Save image 
        imagejpeg($image, $originalPath, $imageQuality);    
        // Return compressed image 
        return $originalPath; 
    }

    public function print_list($imagesList){
        for($i = 0; $i < count($imagesList); $i++)
			{
				// var_dump($elem);
				if(count($imagesList) > 0){
					print '<tr class="oddeven">';
					print '<td><img alt="img" src="/dolibarr/documents/stores/branch'.$imagesList[$i].'" width="100" height="100"></td>';
					print '<td><form action="" method="POST">
                                    <input type="submit" name="delete" value="Delete">
                                    <input type="hidden" name="img" value="'.$i.'">
                                </form></td>';
					print "</tr>";
				}
			}
    }

}